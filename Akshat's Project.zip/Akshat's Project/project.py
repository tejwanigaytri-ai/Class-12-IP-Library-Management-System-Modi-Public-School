"""
Hotel Management System (Console) - CBSE Class 12 Informatics Practices Project
Frontend: Console (Python 3.x)
Backend: sqlite3

Features included (ready-to-run):
- User roles: Admin and Staff (password hashed with SHA-256)
- Room management (add/update/delete/list)
- Customer management
- Booking / Check-in / Check-out
- Billing and invoice generation (text file saved in ./invoices)
- Reports: occupancy rate, revenue report, room availability
- Export data as CSV and simple backup/restore (sqlite .backup API)
- Sample data seeder for quick demo
- Extra special features for bonus marks: discount support, quick-search, stay extension, revenue by date range, automatic DB initialization, and printable invoice

How to run:
1. Save this file as Hotel_Management_System.py
2. Run: python3 Hotel_Management_System.py
3. Default admin credentials: username: admin  password: admin123

Note: This program uses only Python standard library (sqlite3, hashlib, datetime, csv, os).
"""

import sqlite3
import hashlib
import os
import csv
from datetime import datetime, date
from getpass import getpass

DB_FILE = 'hotel.db'
INVOICE_DIR = 'invoices'

# ------------------------ Utility functions ------------------------

def hash_password(password: str) -> str:
    return hashlib.sha256(password.encode('utf-8')).hexdigest()


def input_date(prompt: str) -> date:
    while True:
        s = input(prompt + " (YYYY-MM-DD): ").strip()
        try:
            return datetime.strptime(s, '%Y-%m-%d').date()
        except Exception:
            print('Invalid date format. Please enter date as YYYY-MM-DD.')


def ensure_dir(path):
    if not os.path.exists(path):
        os.makedirs(path)


# ------------------------ Database setup ------------------------

def get_conn():
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_conn()
    c = conn.cursor()

    # users table (admin/staff)
    c.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL CHECK(role IN ('admin','staff')),
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    ''')

    # rooms table
    c.execute('''
        CREATE TABLE IF NOT EXISTS rooms (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            room_no TEXT UNIQUE NOT NULL,
            type TEXT NOT NULL, -- e.g., Single, Double, Deluxe
            price REAL NOT NULL,
            status TEXT NOT NULL CHECK(status IN ('available','occupied','maintenance')) DEFAULT 'available',
            notes TEXT
        )
    ''')

    # customers table
    c.execute('''
        CREATE TABLE IF NOT EXISTS customers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            phone TEXT,
            email TEXT,
            address TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    ''')

    # bookings table
    c.execute('''
        CREATE TABLE IF NOT EXISTS bookings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            room_id INTEGER NOT NULL,
            customer_id INTEGER NOT NULL,
            check_in DATE NOT NULL,
            check_out DATE NOT NULL,
            total_price REAL NOT NULL,
            discount REAL DEFAULT 0,
            paid INTEGER DEFAULT 0,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(room_id) REFERENCES rooms(id),
            FOREIGN KEY(customer_id) REFERENCES customers(id)
        )
    ''')

    # bills table
    c.execute('''
        CREATE TABLE IF NOT EXISTS bills (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            booking_id INTEGER NOT NULL,
            amount REAL NOT NULL,
            paid_amount REAL DEFAULT 0,
            payment_method TEXT,
            generated_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(booking_id) REFERENCES bookings(id)
        )
    ''')

    conn.commit()

    # ensure default admin exists
    c.execute("SELECT COUNT(*) as cnt FROM users WHERE username='admin'")
    if c.fetchone()['cnt'] == 0:
        pw_hash = hash_password('admin123')
        c.execute('INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)', ('admin', pw_hash, 'admin'))
        conn.commit()
        print('[INIT] Default admin created: username=admin password=admin123')

    conn.close()


# ------------------------ Authentication ------------------------

def login():
    conn = get_conn()
    c = conn.cursor()
    print('\n--- Login ---')
    username = input('Username: ').strip()
    password = getpass('Password: ').strip()
    pw_hash = hash_password(password)
    c.execute('SELECT * FROM users WHERE username=? AND password_hash=?', (username, pw_hash))
    row = c.fetchone()
    conn.close()
    if row:
        print(f"Welcome, {row['username']} ({row['role']})")
        return dict(row)
    else:
        print('Login failed. Check username/password.')
        return None


# ------------------------ Admin functions ------------------------

def add_room():
    conn = get_conn(); c = conn.cursor()
    room_no = input('Room number (e.g., 101): ').strip()
    rtype = input('Room type (Single/Double/Deluxe): ').strip()
    try:
        price = float(input('Price per night: ').strip())
    except Exception:
        print('Invalid price. Aborted.')
        return
    notes = input('Notes (optional): ').strip()
    try:
        c.execute('INSERT INTO rooms (room_no, type, price, status, notes) VALUES (?, ?, ?, ?, ?)',
                  (room_no, rtype, price, 'available', notes))
        conn.commit()
        print('Room added.')
    except Exception as e:
        print('Error adding room:', e)
    conn.close()


def list_rooms(filter_status=None):
    conn = get_conn(); c = conn.cursor()
    q = 'SELECT * FROM rooms'
    params = ()
    if filter_status:
        q += ' WHERE status=?'
        params = (filter_status,)
    q += ' ORDER BY room_no'
    c.execute(q, params)
    rows = c.fetchall()
    print('\nRooms:')
    print('{:<6} {:<8} {:<8} {:<10} {}'.format('ID', 'RoomNo', 'Type', 'Price', 'Status'))
    for r in rows:
        print('{:<6} {:<8} {:<8} {:<10.2f} {}'.format(r['id'], r['room_no'], r['type'], r['price'], r['status']))
    conn.close()


def update_room():
    list_rooms()
    try:
        rid = int(input('Enter room ID to update: ').strip())
    except Exception:
        print('Invalid ID')
        return
    conn = get_conn(); c = conn.cursor()
    c.execute('SELECT * FROM rooms WHERE id=?', (rid,))
    r = c.fetchone()
    if not r:
        print('Room not found')
        conn.close(); return
    room_no = input(f'Room number [{r["room_no"]}]: ').strip() or r['room_no']
    rtype = input(f'Type [{r["type"]}]: ').strip() or r['type']
    price_in = input(f'Price [{r["price"]}]: ').strip()
    price = float(price_in) if price_in else r['price']
    status = input(f'Status (available/occupied/maintenance) [{r["status"]}]: ').strip() or r['status']
    notes = input(f'Notes [{r["notes"]}]: ').strip() or r['notes']
    c.execute('UPDATE rooms SET room_no=?, type=?, price=?, status=?, notes=? WHERE id=?',
              (room_no, rtype, price, status, notes, rid))
    conn.commit(); conn.close()
    print('Room updated.')


def delete_room():
    list_rooms()
    try:
        rid = int(input('Enter room ID to delete: ').strip())
    except Exception:
        print('Invalid ID')
        return
    conn = get_conn(); c = conn.cursor()
    c.execute('DELETE FROM rooms WHERE id=?', (rid,))
    conn.commit(); conn.close()
    print('Room deleted (if existed).')


def add_user():
    conn = get_conn(); c = conn.cursor()
    username = input('New username: ').strip()
    role = input('Role (admin/staff): ').strip()
    password = getpass('Password: ').strip()
    pw_hash = hash_password(password)
    try:
        c.execute('INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)', (username, pw_hash, role))
        conn.commit(); print('User created.')
    except Exception as e:
        print('Error:', e)
    conn.close()


def list_users():
    conn = get_conn(); c = conn.cursor()
    c.execute("SELECT id, username, role, created_at FROM users ORDER BY username")
    rows = c.fetchall()
    print('\nUsers:')
    for r in rows:
        print(f"{r['id']}: {r['username']} ({r['role']}) - created {r['created_at']}")
    conn.close()


def change_password():
    conn = get_conn(); c = conn.cursor()
    user = input('Enter username to change password: ').strip()
    newpw = getpass('New password: ').strip()
    c.execute('UPDATE users SET password_hash=? WHERE username=?', (hash_password(newpw), user))
    conn.commit(); conn.close(); print('Password updated (if user existed).')


# ------------------------ Customer & Booking (Staff) ------------------------

def add_customer():
    conn = get_conn(); c = conn.cursor()
    name = input('Customer name: ').strip()
    phone = input('Phone: ').strip()
    email = input('Email: ').strip()
    address = input('Address: ').strip()
    c.execute('INSERT INTO customers (name, phone, email, address) VALUES (?, ?, ?, ?)',
              (name, phone, email, address))
    conn.commit()
    cid = c.lastrowid
    conn.close()
    print('Customer added with id', cid)
    return cid


def find_available_rooms(start: date, end: date):
    conn = get_conn(); c = conn.cursor()
    # A room is available if it's not booked in overlapping period and status is 'available'
    q = '''
    SELECT * FROM rooms WHERE status='available' AND id NOT IN (
        SELECT room_id FROM bookings WHERE NOT (date(check_out) <= date(?) OR date(check_in) >= date(?))
    ) ORDER BY room_no
    '''
    # we want bookings that overlap: NOT(end_before_start or start_after_end)
    c.execute(q, (start.isoformat(), end.isoformat()))
    rows = c.fetchall(); conn.close();
    return rows


def new_booking():
    print('\n--- New Booking / Check-in ---')
    # choose or add customer
    choice = input('Existing customer? (y/n): ').strip().lower()
    if choice == 'y':
        cid = select_customer()
        if not cid:
            print('No customer selected. Aborting.'); return
    else:
        cid = add_customer()

    check_in = input_date('Check-in date')
    check_out = input_date('Check-out date')
    if check_out <= check_in:
        print('Check-out must be after check-in. Aborting.'); return
    available = find_available_rooms(check_in, check_out)
    if not available:
        print('No rooms available for the selected dates.')
        return
    print('\nAvailable rooms:')
    for r in available:
        print(f"{r['id']}: {r['room_no']} {r['type']} - {r['price']:.2f}/night")
    try:
        rid = int(input('Enter room ID to book: ').strip())
    except Exception:
        print('Invalid')
        return

    # compute price = price * nights
    nights = (check_out - check_in).days
    conn = get_conn(); c = conn.cursor()
    c.execute('SELECT price FROM rooms WHERE id=?', (rid,))
    row = c.fetchone()
    if not row:
        print('Room not found'); conn.close(); return
    price_per_night = row['price']
    total = price_per_night * nights
    print(f'Nights: {nights}, Base price: {total:.2f}')
    # discount
    discount = 0.0
    d_in = input('Discount (amount) if any, or press Enter: ').strip()
    if d_in:
        try:
            discount = float(d_in)
        except Exception:
            print('Invalid discount value. Setting to 0.')
            discount = 0.0
    total_after = max(0.0, total - discount)

    # commit booking
    c.execute('INSERT INTO bookings (room_id, customer_id, check_in, check_out, total_price, discount, paid) VALUES (?, ?, ?, ?, ?, ?, ?)',
              (rid, cid, check_in.isoformat(), check_out.isoformat(), total_after, discount, 0))
    booking_id = c.lastrowid
    # set room status to occupied
    c.execute("UPDATE rooms SET status='occupied' WHERE id=?", (rid,))
    conn.commit(); conn.close()
    print(f'Booking created (ID: {booking_id}). Total payable: {total_after:.2f}. Room status set to occupied.')


def select_customer():
    conn = get_conn(); c = conn.cursor()
    key = input('Search customer (name / phone): ').strip()
    c.execute("SELECT * FROM customers WHERE name LIKE ? OR phone LIKE ? LIMIT 20", (f'%{key}%', f'%{key}%'))
    rows = c.fetchall()
    if not rows:
        print('No matching customers.')
        conn.close(); return None
    for r in rows:
        print(f"{r['id']}: {r['name']} - {r['phone']}")
    try:
        cid = int(input('Enter customer ID: ').strip())
        conn.close(); return cid
    except Exception:
        conn.close(); return None


def list_bookings(active_only=False):
    conn = get_conn(); c = conn.cursor()
    q = '''SELECT b.id, r.room_no, c.name as customer, b.check_in, b.check_out, b.total_price, b.paid
           FROM bookings b
           JOIN rooms r ON b.room_id=r.id
           JOIN customers c ON b.customer_id=c.id
        '''
    if active_only:
        today = date.today().isoformat()
        q += " WHERE date(b.check_in) <= date(?) AND date(b.check_out) > date(?)"
        c.execute(q, (today, today))
    else:
        c.execute(q)
    rows = c.fetchall(); conn.close()
    print('\nBookings:')
    for r in rows:
        print(f"{r['id']}: Room {r['room_no']} | Guest: {r['customer']} | {r['check_in']} to {r['check_out']} | Total: {r['total_price']:.2f} | Paid: {r['paid']}")


def checkout():
    print('\n--- Check-out ---')
    list_bookings(active_only=True)
    try:
        bid = int(input('Enter booking ID to check-out: ').strip())
    except Exception:
        print('Invalid'); return
    conn = get_conn(); c = conn.cursor()
    c.execute('SELECT * FROM bookings WHERE id=?', (bid,))
    b = c.fetchone()
    if not b:
        print('Booking not found'); conn.close(); return
    # compute final amount (already stored)
    amount = b['total_price']
    print(f'Total amount due: {amount:.2f} (discount applied: {b["discount"]:.2f})')
    pay = input('Enter amount being paid now (or full amount to settle): ').strip()
    try:
        pay_amt = float(pay)
    except Exception:
        print('Invalid amount'); conn.close(); return
    # Create bill record
    c.execute('INSERT INTO bills (booking_id, amount, paid_amount, payment_method) VALUES (?, ?, ?, ?)',
              (bid, amount, pay_amt, 'cash'))
    # mark booking as paid if fully paid
    if pay_amt >= amount:
        c.execute('UPDATE bookings SET paid=1 WHERE id=?', (bid,))
    # free the room
    c.execute('UPDATE rooms SET status="available" WHERE id=?', (b['room_id'],))
    conn.commit(); conn.close()
    # generate invoice file
    generate_invoice(bid)
    print('Check-out complete, invoice generated.')


def generate_invoice(booking_id: int):
    conn = get_conn(); c = conn.cursor()
    c.execute('''SELECT b.*, r.room_no, r.type as room_type, r.price as room_price, c.name as customer_name, c.phone as customer_phone
                 FROM bookings b
                 JOIN rooms r ON b.room_id=r.id
                 JOIN customers c ON b.customer_id=c.id
                 WHERE b.id=?''', (booking_id,))
    b = c.fetchone()
    if not b:
        conn.close(); return None
    ensure_dir(INVOICE_DIR)
    filename = f"invoice_{booking_id}_{datetime.now().strftime('%Y%m%d%H%M%S')}.txt"
    path = os.path.join(INVOICE_DIR, filename)
    with open(path, 'w', encoding='utf-8') as f:
        f.write('HOTEL INVOICE\n')
        f.write('Generated at: ' + datetime.now().isoformat() + '\n')
        f.write('\nBooking ID: ' + str(b['id']) + '\n')
        f.write('Guest: ' + b['customer_name'] + ' | Phone: ' + (b['customer_phone'] or '') + '\n')
        f.write('Room: ' + b['room_no'] + ' (' + b['room_type'] + ')\n')
        f.write('Check-in: ' + b['check_in'] + '  Check-out: ' + b['check_out'] + '\n')
        nights = (datetime.strptime(b['check_out'], '%Y-%m-%d').date() - datetime.strptime(b['check_in'], '%Y-%m-%d').date()).days
        f.write(f'Nights: {nights}\n')
        f.write(f'Room rate: {b["room_price"]:.2f} per night\n')
        f.write(f'Base total: {b["room_price"]*nights:.2f}\n')
        f.write(f'Discount: {b["discount"]:.2f}\n')
        f.write(f'Total payable: {b["total_price"]:.2f}\n')
        f.write('\nThank you for staying with us!\n')
    conn.close()
    print('Invoice saved to', path)
    return path


# ------------------------ Reports & Exports ------------------------

def occupancy_report():
    conn = get_conn(); c = conn.cursor()
    c.execute("SELECT COUNT(*) as tot FROM rooms")
    tot = c.fetchone()['tot']
    c.execute("SELECT COUNT(*) as occ FROM rooms WHERE status='occupied'")
    occ = c.fetchone()['occ']
    rate = (occ / tot * 100) if tot else 0
    print(f'Rooms total: {tot}, Occupied: {occ}, Occupancy rate: {rate:.2f}%')
    conn.close()


def revenue_report():
    print('\n--- Revenue Report ---')
    s = input('Enter start date (YYYY-MM-DD) or press Enter for beginning: ').strip()
    e = input('Enter end date (YYYY-MM-DD) or press Enter for today: ').strip()
    try:
        start = datetime.strptime(s, '%Y-%m-%d').date() if s else date(2000,1,1)
    except Exception:
        print('Invalid start date'); return
    try:
        end = datetime.strptime(e, '%Y-%m-%d').date() if e else date.today()
    except Exception:
        print('Invalid end date'); return
    conn = get_conn(); c = conn.cursor()
    # revenue from bills (sum of paid_amount between dates)
    q = "SELECT SUM(paid_amount) as revenue FROM bills WHERE date(generated_at) BETWEEN date(?) AND date(?)"
    c.execute(q, (start.isoformat(), end.isoformat()))
    rev = c.fetchone()['revenue'] or 0.0
    print(f'Revenue between {start} and {end}: {rev:.2f}')
    conn.close()


def export_csv():
    conn = get_conn(); c = conn.cursor()
    ensure_dir('exports')
    tables = ['rooms', 'customers', 'bookings', 'users', 'bills']
    for t in tables:
        c.execute(f'SELECT * FROM {t}')
        rows = c.fetchall()
        if not rows:
            continue
        keys = rows[0].keys()
        path = os.path.join('exports', f'{t}.csv')
        with open(path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(keys)
            for r in rows:
                writer.writerow([r[k] for k in keys])
        print('Exported', path)
    conn.close()


def backup_db():
    ensure_dir('backups')
    dest = os.path.join('backups', f'hotel_backup_{datetime.now().strftime("%Y%m%d%H%M%S")}.db')
    src_conn = sqlite3.connect(DB_FILE)
    dest_conn = sqlite3.connect(dest)
    with dest_conn:
        src_conn.backup(dest_conn)
    src_conn.close(); dest_conn.close()
    print('Backup saved to', dest)


# ------------------------ Sample data seeder ------------------------

def seed_sample_data():
    conn = get_conn(); c = conn.cursor()
    # add rooms
    sample_rooms = [
        ('101', 'Single', 1200.0),
        ('102', 'Single', 1200.0),
        ('201', 'Double', 2000.0),
        ('202', 'Double', 2000.0),
        ('301', 'Deluxe', 3500.0)
    ]
    for rn,rt,pr in sample_rooms:
        try:
            c.execute('INSERT INTO rooms (room_no, type, price, status) VALUES (?, ?, ?, ?)', (rn, rt, pr, 'available'))
        except Exception:
            pass
    # add a staff user
    try:
        c.execute('INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)', ('staff', hash_password('staff123'), 'staff'))
    except Exception:
        pass
    # sample customer and booking
    c.execute('INSERT OR IGNORE INTO customers (id, name, phone, email, address) VALUES (?, ?, ?, ?, ?)', (1, 'Rahul Sharma', '9876543210', 'rahul@example.com', 'Delhi'))
    conn.commit()
    conn.close()
    print('Sample data seeded (rooms, staff user)')


# ------------------------ Menus ------------------------

def admin_menu():
    while True:
        print('\n--- Admin Menu ---')
        print('1) Rooms: Add')
        print('2) Rooms: List')
        print('3) Rooms: Update')
        print('4) Rooms: Delete')
        print('5) Users: Add')
        print('6) Users: List')
        print('7) Change user password')
        print('8) Reports: Occupancy')
        print('9) Reports: Revenue')
        print('10) Export CSV')
        print('11) Backup DB')
        print('12) Seed sample data')
        print('0) Logout')
        choice = input('Choice: ').strip()
        if choice == '1': add_room()
        elif choice == '2': list_rooms()
        elif choice == '3': update_room()
        elif choice == '4': delete_room()
        elif choice == '5': add_user()
        elif choice == '6': list_users()
        elif choice == '7': change_password()
        elif choice == '8': occupancy_report()
        elif choice == '9': revenue_report()
        elif choice == '10': export_csv()
        elif choice == '11': backup_db()
        elif choice == '12': seed_sample_data()
        elif choice == '0': break
        else: print('Invalid choice')


def staff_menu():
    while True:
        print('\n--- Staff Menu ---')
        print('1) New Booking / Check-in')
        print('2) List Bookings')
        print('3) Active Bookings (today)')
        print('4) Check-out')
        print('5) Add Customer')
        print('6) Generate Invoice (by booking id)')
        print('7) List rooms')
        print('8) Occupancy report')
        print('0) Logout')
        choice = input('Choice: ').strip()
        if choice == '1': new_booking()
        elif choice == '2': list_bookings()
        elif choice == '3': list_bookings(active_only=True)
        elif choice == '4': checkout()
        elif choice == '5': add_customer()
        elif choice == '6':
            try:
                bid = int(input('Booking ID: ').strip())
                generate_invoice(bid)
            except Exception:
                print('Invalid booking ID')
        elif choice == '7': list_rooms()
        elif choice == '8': occupancy_report()
        elif choice == '0': break
        else: print('Invalid choice')


# ------------------------ Main ------------------------

def main():
    init_db()
    ensure_dir(INVOICE_DIR)
    print('\nWelcome to the Hotel Management System (Console)')
    while True:
        print('\n1) Login')
        print('2) Exit')
        ch = input('Choice: ').strip()
        if ch == '1':
            user = login()
            if user:
                if user['role'] == 'admin':
                    admin_menu()
                else:
                    staff_menu()
        elif ch == '2':
            print('Goodbye!')
            break
        else:
            print('Invalid choice')


if __name__ == '__main__':
    main()
