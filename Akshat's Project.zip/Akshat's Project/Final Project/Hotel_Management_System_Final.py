
"""
Hotel Management System (Final) - CBSE Class 12 IP Project
Frontend: Console (Python 3.x)
Backend: sqlite3
Features:
 - Users: admin/staff with SHA-256 passwords and 3-attempt lockout
 - Rooms: add/list/update/delete
 - Customers: add/search
 - Bookings: create, extend stay, cancel, list
 - Room Services: create services, assign to bookings
 - Billing: discounts, CGST(9%) + SGST(9%), multiple payment methods, pending balance
 - Invoices: TXT files saved to ./invoices with tax & service breakdown
 - Analytics: matplotlib charts (Revenue over time, Daily bookings, Room type pie, Revenue by room type & avg stay)
 - Export/Backup: CSV export + sqlite backup
 - Sample data seeder
How to run:
    python3 /mnt/data/Hotel_Management_System_Final.py
Default admin: username=admin password=admin123
"""
import sqlite3, hashlib, os, csv
from datetime import datetime, date
from getpass import getpass
import matplotlib.pyplot as plt

DB_FILE = 'hotel.db'
INVOICE_DIR = 'invoices'
EXPORT_DIR = 'exports'
BACKUP_DIR = 'backups'

# ----------------- Utilities -----------------
def hash_password(p): return hashlib.sha256(p.encode()).hexdigest()
def ensure_dir(d): 
    if not os.path.exists(d): os.makedirs(d)

def input_date(prompt):
    while True:
        s = input(f"{prompt} (YYYY-MM-DD): ").strip()
        try:
            return datetime.strptime(s, "%Y-%m-%d").date()
        except:
            print("Invalid date format.")

# ----------------- DB Setup -----------------
def get_conn():
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_conn(); c = conn.cursor()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL CHECK(role IN ('admin','staff')),
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        locked INTEGER DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS rooms (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        room_no TEXT UNIQUE NOT NULL,
        type TEXT NOT NULL,
        price REAL NOT NULL,
        status TEXT NOT NULL DEFAULT 'available',
        notes TEXT
    );
    CREATE TABLE IF NOT EXISTS customers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        phone TEXT,
        email TEXT,
        address TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS bookings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        room_id INTEGER NOT NULL,
        customer_id INTEGER NOT NULL,
        check_in DATE NOT NULL,
        check_out DATE NOT NULL,
        total_price REAL NOT NULL,
        discount REAL DEFAULT 0,
        paid INTEGER DEFAULT 0,
        status TEXT DEFAULT 'active',
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(room_id) REFERENCES rooms(id),
        FOREIGN KEY(customer_id) REFERENCES customers(id)
    );
    CREATE TABLE IF NOT EXISTS bills (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        booking_id INTEGER NOT NULL,
        amount REAL NOT NULL,
        paid_amount REAL DEFAULT 0,
        payment_method TEXT,
        generated_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(booking_id) REFERENCES bookings(id)
    );
    CREATE TABLE IF NOT EXISTS services (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        price REAL NOT NULL
    );
    CREATE TABLE IF NOT EXISTS service_usage (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        booking_id INTEGER NOT NULL,
        service_id INTEGER NOT NULL,
        qty INTEGER NOT NULL DEFAULT 1,
        FOREIGN KEY(booking_id) REFERENCES bookings(id),
        FOREIGN KEY(service_id) REFERENCES services(id)
    );
    """)
    conn.commit()
    # default admin
    c.execute("SELECT COUNT(*) as cnt FROM users WHERE username='admin'")
    if c.fetchone()['cnt'] == 0:
        c.execute("INSERT INTO users (username, password_hash, role) VALUES (?,?,?)",
                  ('admin', hash_password('admin123'), 'admin'))
        conn.commit()
        print("[INIT] Default admin created: admin/admin123")
    conn.close()

# ----------------- Auth -----------------
def login():
    conn = get_conn(); c = conn.cursor()
    username = input("Username: ").strip()
    c.execute("SELECT * FROM users WHERE username=?", (username,))
    row = c.fetchone()
    if not row:
        print("User not found.")
        conn.close(); return None
    if row['locked']:
        print("Account locked. Contact admin."); conn.close(); return None
    attempts = 0
    while attempts < 3:
        pw = getpass("Password: ")
        if hash_password(pw) == row['password_hash']:
            conn.close()
            print(f"Welcome {row['username']} ({row['role']})")
            return dict(row)
        attempts += 1
        print("Incorrect password.")
    # lock account
    conn = get_conn(); c = conn.cursor()
    c.execute("UPDATE users SET locked=1 WHERE username=?", (username,))
    conn.commit(); conn.close()
    print("Too many failed attempts. Account locked.")
    return None

# ----------------- Admin functions -----------------
def add_room():
    conn = get_conn(); c = conn.cursor()
    rn = input("Room no: "); rt = input("Type (Single/Double/Deluxe): ")
    try:
        pr = float(input("Price per night: "))
    except:
        print("Invalid price"); conn.close(); return
    notes = input("Notes (optional): ")
    try:
        c.execute("INSERT INTO rooms (room_no,type,price,notes) VALUES (?,?,?,?)",(rn,rt,pr,notes))
        conn.commit(); print("Room added.")
    except Exception as e:
        print("Error:",e)
    conn.close()

def update_room():
    list_rooms()
    try:
        rid = int(input("Room ID to update: "))
    except: print("Invalid"); return
    conn = get_conn(); c = conn.cursor()
    c.execute("SELECT * FROM rooms WHERE id=?", (rid,))
    r=c.fetchone()
    if not r: print("Not found"); conn.close(); return
    rn = input(f"Room no [{r['room_no']}]: ") or r['room_no']
    rt = input(f"Type [{r['type']}]: ") or r['type']
    p_in = input(f"Price [{r['price']}]: ")
    price = float(p_in) if p_in else r['price']
    status = input(f"Status [{r['status']}]: ") or r['status']
    notes = input(f"Notes [{r['notes'] or ''}]: ") or r['notes']
    c.execute("UPDATE rooms SET room_no=?,type=?,price=?,status=?,notes=? WHERE id=?",(rn,rt,price,status,notes,rid))
    conn.commit(); conn.close(); print("Updated.")

def delete_room():
    list_rooms()
    try:
        rid=int(input("Room ID to delete: "))
    except: print("Invalid"); return
    conn=get_conn(); c=conn.cursor()
    c.execute("DELETE FROM rooms WHERE id=?", (rid,)); conn.commit(); conn.close(); print("Deleted (if existed).")

def list_rooms():
    conn=get_conn(); c=conn.cursor()
    c.execute("SELECT * FROM rooms ORDER BY room_no")
    rows=c.fetchall(); conn.close()
    print("\nID | Room | Type | Price | Status")
    for r in rows:
        print(r['id'], r['room_no'], r['type'], f"₹{r['price']:.2f}", r['status'])

def add_user():
    conn=get_conn(); c=conn.cursor()
    un=input("Username: "); role=input("Role (admin/staff): ")
    pw=getpass("Password: "); 
    try:
        c.execute("INSERT INTO users (username,password_hash,role) VALUES (?,?,?)",(un,hash_password(pw),role))
        conn.commit(); print("User added.")
    except Exception as e:
        print("Error:",e)
    conn.close()

def list_users():
    conn=get_conn(); c=conn.cursor()
    c.execute("SELECT id,username,role,created_at,locked FROM users")
    for r in c.fetchall(): print(r['id'],r['username'],r['role'],r['created_at'], "Locked" if r['locked'] else "")
    conn.close()

def change_password():
    conn=get_conn(); c=conn.cursor()
    user=input("Username to change: "); newpw=getpass("New Password: ")
    c.execute("UPDATE users SET password_hash=?, locked=0 WHERE username=?",(hash_password(newpw),user))
    conn.commit(); conn.close(); print("Password changed & account unlocked.")

# ----------------- Customer & Booking -----------------
def add_customer():
    conn=get_conn(); c=conn.cursor()
    name=input("Name: "); phone=input("Phone: "); email=input("Email: "); addr=input("Address: ")
    c.execute("INSERT INTO customers (name,phone,email,address) VALUES (?,?,?,?)",(name,phone,email,addr))
    conn.commit(); cid=c.lastrowid; conn.close(); print("Customer ID:",cid); return cid

def select_customer():
    conn=get_conn(); c=conn.cursor()
    k=input("Search name/phone: ")
    c.execute("SELECT * FROM customers WHERE name LIKE ? OR phone LIKE ? LIMIT 20", ('%'+k+'%','%'+k+'%'))
    rows=c.fetchall(); conn.close()
    if not rows: print("No matches"); return None
    for r in rows: print(r['id'],r['name'], r['phone'])
    return int(input("Choose ID: "))

def find_available_rooms(ci,co):
    conn=get_conn(); c=conn.cursor()
    c.execute("""SELECT * FROM rooms WHERE status='available' AND id NOT IN (
                 SELECT room_id FROM bookings WHERE NOT (date(check_out)<=date(?) OR date(check_in)>=date(?))
                 )""",(ci.isoformat(), co.isoformat()))
    rows=c.fetchall(); conn.close(); return rows

def new_booking():
    print("--- New Booking ---")
    if input("Existing customer? (y/n): ").lower()=='y':
        cid = select_customer()
        if not cid: return
    else:
        cid = add_customer()
    ci=input_date("Check-in"); co=input_date("Check-out")
    if co <= ci: print("Invalid dates"); return
    available = find_available_rooms(ci,co)
    if not available: print("No rooms"); return
    for r in available: print(r['id'], r['room_no'], r['type'], f"₹{r['price']}")
    rid=int(input("Room ID to book: "))
    nights=(co-ci).days
    conn=get_conn(); c=conn.cursor()
    c.execute("SELECT price FROM rooms WHERE id=?", (rid,)); row=c.fetchone()
    if not row: print("Room not found"); conn.close(); return
    base = row['price']*nights
    print(f"Nights: {nights}, Base: ₹{base:.2f}")
    try: discount=float(input("Discount amount if any (0): ") or 0)
    except: discount=0
    total_after = max(base-discount,0)
    c.execute("INSERT INTO bookings (room_id,customer_id,check_in,check_out,total_price,discount) VALUES (?,?,?,?,?,?)",
              (rid,cid,ci.isoformat(),co.isoformat(),total_after,discount))
    bid = c.lastrowid
    c.execute("UPDATE rooms SET status='occupied' WHERE id=?", (rid,))
    conn.commit(); conn.close(); print("Booked ID:",bid)

def list_bookings(active_only=False):
    conn=get_conn(); c=conn.cursor()
    q = "SELECT b.*, r.room_no, c.name as customer FROM bookings b JOIN rooms r ON b.room_id=r.id JOIN customers c ON b.customer_id=c.id"
    if active_only:
        today = date.today().isoformat()
        q += " WHERE date(b.check_in)<=date(?) AND date(b.check_out)>date(?)"
        c.execute(q,(today,today))
    else:
        c.execute(q)
    rows=c.fetchall(); conn.close()
    for r in rows:
        print(r['id'], r['room_no'], r['customer'], r['check_in'], r['check_out'], f"₹{r['total_price']:.2f}", "Paid" if r['paid'] else "NotPaid", r['status'])

def cancel_booking():
    list_bookings()
    try:
        bid=int(input("Booking ID to cancel: "))
    except: print("Invalid"); return
    conn=get_conn(); c=conn.cursor()
    c.execute("SELECT * FROM bookings WHERE id=?", (bid,)); b=c.fetchone()
    if not b: print("Not found"); conn.close(); return
    # free room and mark cancelled
    c.execute("UPDATE bookings SET status='cancelled' WHERE id=?", (bid,))
    c.execute("UPDATE rooms SET status='available' WHERE id=?", (b['room_id'],))
    conn.commit(); conn.close(); print("Cancelled booking", bid)

def extend_stay():
    list_bookings(active_only=True)
    try: bid=int(input("Booking ID to extend: "))
    except: print("Invalid"); return
    conn=get_conn(); c=conn.cursor()
    c.execute("SELECT * FROM bookings WHERE id=?", (bid,)); b=c.fetchone()
    if not b: print("Not found"); conn.close(); return
    new_co = input_date("New Check-out Date")
    if new_co <= datetime.strptime(b['check_out'], "%Y-%m-%d").date(): print("New date must be after current"); conn.close(); return
    nights_add = (new_co - datetime.strptime(b['check_out'], "%Y-%m-%d").date()).days
    # price per night from room
    c.execute("SELECT price FROM rooms WHERE id=?", (b['room_id'],)); price=c.fetchone()['price']
    add_cost = price * nights_add
    new_total = float(b['total_price']) + add_cost
    c.execute("UPDATE bookings SET check_out=?, total_price=? WHERE id=?", (new_co.isoformat(), new_total, bid))
    conn.commit(); conn.close(); print(f"Extended. Additional cost: ₹{add_cost:.2f}")

# ----------------- Services -----------------
def add_service():
    conn=get_conn(); c=conn.cursor()
    name=input("Service name: "); 
    try: price=float(input("Price: "))
    except: print("Invalid"); conn.close(); return
    c.execute("INSERT INTO services (name,price) VALUES (?,?)",(name,price))
    conn.commit(); conn.close(); print("Service added.")

def list_services():
    conn=get_conn(); c=conn.cursor()
    c.execute("SELECT * FROM services"); rows=c.fetchall(); conn.close()
    for r in rows: print(r['id'], r['name'], f"₹{r['price']:.2f}")

def assign_service_to_booking():
    list_bookings()
    try: bid=int(input("Booking ID: "))
    except: print("Invalid"); return
    list_services()
    try: sid=int(input("Service ID: ")); qty=int(input("Qty: "))
    except: print("Invalid"); return
    conn=get_conn(); c=conn.cursor()
    c.execute("INSERT INTO service_usage (booking_id, service_id, qty) VALUES (?,?,?)",(bid,sid,qty))
    conn.commit(); conn.close(); print("Service assigned.")

# ----------------- Billing & Invoice -----------------
def checkout_and_bill():
    list_bookings(active_only=True)
    try: bid=int(input("Booking ID to checkout: "))
    except: print("Invalid"); return
    conn=get_conn(); c=conn.cursor()
    c.execute("SELECT * FROM bookings WHERE id=?", (bid,)); b=c.fetchone()
    if not b: print("Not found"); conn.close(); return
    # subtotal from booking
    subtotal = float(b['total_price'])
    # add services cost
    c.execute("""SELECT s.price, su.qty FROM service_usage su JOIN services s ON su.service_id=s.id
                 WHERE su.booking_id=?""", (bid,))
    servs = c.fetchall()
    serv_total = sum([row['price']*row['qty'] for row in servs]) if servs else 0.0
    subtotal += serv_total
    # GST on subtotal (after discount scenario already in booking total)
    cgst = round(subtotal*0.09,2); sgst = round(subtotal*0.09,2)
    grand = round(subtotal+cgst+sgst,2)
    print(f"Subtotal incl services: ₹{subtotal:.2f}")
    print(f"CGST 9%: ₹{cgst:.2f} | SGST 9%: ₹{sgst:.2f} | Grand Total: ₹{grand:.2f}")
    pm = input("Payment method (UPI/Card/Cash): ")
    try: paid = float(input("Amount paid now: "))
    except: print("Invalid"); conn.close(); return
    c.execute("INSERT INTO bills (booking_id,amount,paid_amount,payment_method) VALUES (?,?,?,?)",(bid,grand,paid,pm))
    c.execute("UPDATE bookings SET paid=?, status='completed' WHERE id=?", (1 if paid>=grand else 0, bid))
    c.execute("UPDATE rooms SET status='available' WHERE id=?", (b['room_id'],))
    conn.commit(); conn.close()
    generate_invoice(bid); print("Checked out & invoice generated.")

def generate_invoice(bid):
    conn=get_conn(); c=conn.cursor()
    c.execute("""SELECT b.*, r.room_no, r.type as room_type, r.price as room_price, 
                 cu.name as customer_name, cu.phone as customer_phone
                 FROM bookings b
                 JOIN rooms r ON b.room_id=r.id
                 JOIN customers cu ON b.customer_id=cu.id
                 WHERE b.id=?""",(bid,))
    b=c.fetchone()
    if not b: conn.close(); print("Booking missing"); return
    c.execute("SELECT * FROM bills WHERE booking_id=? ORDER BY id DESC LIMIT 1",(bid,)); bill=c.fetchone()
    paid = float(bill['paid_amount']) if bill else 0.0
    pm = bill['payment_method'] if bill and bill['payment_method'] else "N/A"
    # services
    c.execute("""SELECT s.name, s.price, su.qty FROM service_usage su JOIN services s ON su.service_id=s.id
                 WHERE su.booking_id=?""",(bid,))
    servs=c.fetchall()
    serv_total = sum([row['price']*row['qty'] for row in servs]) if servs else 0.0
    subtotal = float(b['total_price']) + serv_total
    cgst = round(subtotal*0.09,2); sgst = round(subtotal*0.09,2)
    grand = round(subtotal+cgst+sgst,2)
    pending = round(grand-paid,2)
    ensure_dir(INVOICE_DIR)
    fname = f"invoice_{bid}_{datetime.now().strftime('%Y%m%d%H%M%S')}.txt"
    path = os.path.join(INVOICE_DIR, fname)
    with open(path,'w',encoding='utf-8') as f:
        f.write("===== HOTEL INVOICE =====\n")
        f.write(f"Date: {datetime.now().strftime('%Y-%m-%d %H:%M')}\n\n")
        f.write(f"Booking ID: {b['id']}\nGuest: {b['customer_name']} | Phone: {b['customer_phone']}\n")
        f.write(f"Room: {b['room_no']} ({b['room_type']})\n")
        f.write(f"Stay: {b['check_in']} to {b['check_out']}\n")
        nights = (datetime.strptime(b['check_out'],'%Y-%m-%d').date() - datetime.strptime(b['check_in'],'%Y-%m-%d').date()).days
        f.write(f"Nights: {nights}\n\n")
        f.write(f"Room charges (incl discount applied earlier): ₹{b['total_price']:.2f}\n")
        if servs:
            f.write("\n--- Services ---\n")
            for s in servs: f.write(f"{s['name']} x{s['qty']} @ ₹{s['price']:.2f} = ₹{s['price']*s['qty']:.2f}\n")
            f.write(f"Services Total: ₹{serv_total:.2f}\n")
        f.write(f"\nSubtotal: ₹{subtotal:.2f}\n")
        f.write(f"CGST 9%: ₹{cgst:.2f}\nSGST 9%: ₹{sgst:.2f}\n")
        f.write(f"Grand Total: ₹{grand:.2f}\n\n")
        f.write(f"Payment Method: {pm}\nAmount Paid: ₹{paid:.2f}\nPending Balance: ₹{pending:.2f}\n")
        f.write("\nThank you for staying with us!\n")
    conn.close(); print("Invoice saved to", path); return path

# ----------------- Analytics (Matplotlib) -----------------
def analytics_menu():
    while True:
        print("\n--- Analytics & Charts ---")
        print("1) Revenue Over Time (line)")
        print("2) Daily Bookings (bar)")
        print("3) Room Type Distribution (pie)")
        print("4) Revenue by Room Type + Avg Stay (dual)")
        print("0) Back")
        ch=input("Choice: ").strip()
        if ch=='1': show_revenue_graph()
        elif ch=='2': show_daily_bookings_graph()
        elif ch=='3': show_room_type_pie()
        elif ch=='4': show_advanced_dual_charts()
        elif ch=='0': break
        else: print("Invalid")

def show_revenue_graph():
    conn=get_conn(); c=conn.cursor()
    c.execute("SELECT date(generated_at) d, SUM(paid_amount) s FROM bills GROUP BY d ORDER BY d")
    rows=c.fetchall(); conn.close()
    if not rows: print("No data"); return
    dates=[r['d'] for r in rows]; totals=[r['s'] for r in rows]
    plt.figure(); plt.plot(dates, totals); plt.title("Revenue Over Time"); plt.xticks(rotation=45); plt.tight_layout(); plt.show()

def show_daily_bookings_graph():
    conn=get_conn(); c=conn.cursor()
    c.execute("SELECT date(check_in) d, COUNT(*) c FROM bookings GROUP BY d ORDER BY d")
    rows=c.fetchall(); conn.close()
    if not rows: print("No data"); return
    dates=[r['d'] for r in rows]; counts=[r['c'] for r in rows]
    plt.figure(); plt.bar(dates, counts); plt.title("Daily Bookings"); plt.xticks(rotation=45); plt.tight_layout(); plt.show()

def show_room_type_pie():
    conn=get_conn(); c=conn.cursor()
    c.execute("SELECT type, COUNT(*) cnt FROM rooms GROUP BY type")
    rows=c.fetchall(); conn.close()
    if not rows: print("No data"); return
    labels=[r['type'] for r in rows]; sizes=[r['cnt'] for r in rows]
    plt.figure(); plt.pie(sizes, labels=labels, autopct='%1.1f%%'); plt.title("Room Type Distribution"); plt.tight_layout(); plt.show()

def show_advanced_dual_charts():
    conn=get_conn(); c=conn.cursor()
    c.execute("SELECT r.type, SUM(b.total_price) tot FROM bookings b JOIN rooms r ON b.room_id=r.id GROUP BY r.type")
    rev = c.fetchall()
    if rev:
        types=[r['type'] for r in rev]; totals=[r['tot'] for r in rev]
        plt.figure(); plt.bar(types, totals); plt.title("Revenue by Room Type"); plt.tight_layout(); plt.show()
    c.execute("SELECT customer_id, AVG(julianday(check_out)-julianday(check_in)) avgd FROM bookings GROUP BY customer_id")
    stay=c.fetchall(); conn.close()
    if stay:
        idx=list(range(len(stay))); avg=[round(s['avgd'],2) for s in stay]
        plt.figure(); plt.plot(idx, avg, marker='o'); plt.title("Avg Stay per Customer"); plt.tight_layout(); plt.show()

# ----------------- Reports & Exports -----------------
def occupancy_report():
    conn=get_conn(); c=conn.cursor()
    c.execute("SELECT COUNT(*) tot FROM rooms"); tot=c.fetchone()['tot']
    c.execute("SELECT COUNT(*) occ FROM rooms WHERE status='occupied'"); occ=c.fetchone()['occ']
    conn.close(); rate=(occ/tot*100) if tot else 0
    print(f"Total: {tot}, Occupied: {occ}, Occupancy: {rate:.2f}%")

def revenue_report():
    s=input("Start date (YYYY-MM-DD) or Enter: ").strip(); e=input("End date or Enter: ").strip()
    try: start=datetime.strptime(s,'%Y-%m-%d').date() if s else date(2000,1,1)
    except: print("Invalid"); return
    try: end=datetime.strptime(e,'%Y-%m-%d').date() if e else date.today()
    except: print("Invalid"); return
    conn=get_conn(); c=conn.cursor()
    c.execute("SELECT SUM(paid_amount) r FROM bills WHERE date(generated_at) BETWEEN date(?) AND date(?)",(start.isoformat(), end.isoformat()))
    rev=c.fetchone()['r'] or 0.0; conn.close()
    print(f"Revenue {start} to {end}: ₹{rev:.2f}")

def export_csv():
    ensure_dir(EXPORT_DIR)
    tables=['rooms','customers','bookings','users','bills','services','service_usage']
    conn=get_conn(); c=conn.cursor()
    for t in tables:
        c.execute(f"SELECT * FROM {t}")
        rows=c.fetchall()
        if not rows: continue
        keys=rows[0].keys()
        path=os.path.join(EXPORT_DIR, f"{t}.csv")
        with open(path,'w',newline='',encoding='utf-8') as f:
            writer=csv.writer(f); writer.writerow(keys)
            for r in rows: writer.writerow([r[k] for k in keys])
        print("Exported", path)
    conn.close()

def backup_db():
    ensure_dir(BACKUP_DIR)
    dest=os.path.join(BACKUP_DIR, f"hotel_backup_{datetime.now().strftime('%Y%m%d%H%M%S')}.db")
    src_conn=sqlite3.connect(DB_FILE); dest_conn=sqlite3.connect(dest)
    with dest_conn: src_conn.backup(dest_conn)
    src_conn.close(); dest_conn.close()
    print("Backup saved to", dest)

# ----------------- Sample Data -----------------
def seed_sample():
    conn=get_conn(); c=conn.cursor()
    rooms=[('101','Single',1200.0),('102','Single',1200.0),('201','Double',2000.0),('202','Double',2000.0),('301','Deluxe',3500.0)]
    for rn,rt,pr in rooms:
        try: c.execute("INSERT INTO rooms (room_no,type,price) VALUES (?,?,?)",(rn,rt,pr))
        except: pass
    try: c.execute("INSERT INTO users (username,password_hash,role) VALUES (?,?,?)",('staff',hash_password('staff123'),'staff'))
    except: pass
    try: c.execute("INSERT INTO customers (id,name,phone,email,address) VALUES (?,?,?,?,?)",(1,'Rahul Sharma','9876543210','rahul@example.com','Delhi'))
    except: pass
    conn.commit(); conn.close(); print("Sample data seeded.")

# ----------------- Menus -----------------
def admin_menu():
    while True:
        print("\n--- Admin Menu ---")
        print("1) Add Room 2) List Rooms 3) Update Room 4) Delete Room")
        print("5) Add User 6) List Users 7) Change Password 8) Seed Data")
        print("9) Reports 10) Export CSV 11) Backup DB 12) Services 13) Analytics 0) Logout")
        ch=input("Choice: ").strip()
        if ch=='1': add_room()
        elif ch=='2': list_rooms()
        elif ch=='3': update_room()
        elif ch=='4': delete_room()
        elif ch=='5': add_user()
        elif ch=='6': list_users()
        elif ch=='7': change_password()
        elif ch=='8': seed_sample()
        elif ch=='9':
            print("a) Occupancy b) Revenue")
            sb=input("Choice: ").strip().lower()
            if sb=='a': occupancy_report()
            elif sb=='b': revenue_report()
        elif ch=='10': export_csv()
        elif ch=='11': backup_db()
        elif ch=='12':
            print("Service: a) Add b) List c) Assign")
            s=input("Choice: ").strip().lower()
            if s=='a': add_service()
            elif s=='b': list_services()
            elif s=='c': assign_service_to_booking()
        elif ch=='13': analytics_menu()
        elif ch=='0': break
        else: print("Invalid")

def staff_menu():
    while True:
        print("\n--- Staff Menu ---")
        print("1) New Booking 2) List Bookings 3) Active Bookings 4) Checkout & Bill")
        print("5) Add Customer 6) Generate Invoice 7) Services 8) Cancel 9) Extend Stay 0) Logout")
        ch=input("Choice: ").strip()
        if ch=='1': new_booking()
        elif ch=='2': list_bookings()
        elif ch=='3': list_bookings(active_only=True)
        elif ch=='4': checkout_and_bill()
        elif ch=='5': add_customer()
        elif ch=='6': 
            try: bid=int(input("Booking ID: ")); generate_invoice(bid)
            except: print("Invalid")
        elif ch=='7':
            print("a) Add Service b) List c) Assign")
            s=input("Choice: ").strip().lower()
            if s=='a': add_service()
            elif s=='b': list_services()
            elif s=='c': assign_service_to_booking()
        elif ch=='8': cancel_booking()
        elif ch=='9': extend_stay()
        elif ch=='0': break
        else: print("Invalid")

def main():
    init_db(); ensure_dir(INVOICE_DIR); ensure_dir(EXPORT_DIR); ensure_dir(BACKUP_DIR)
    print("Welcome to Hotel Management System (Final)")
    while True:
        print("\n1) Login 2) Exit")
        ch=input("Choice: ").strip()
        if ch=='1':
            user=login()
            if user:
                if user['role']=='admin': admin_menu()
                else: staff_menu()
        elif ch=='2': print("Goodbye"); break
        else: print("Invalid")

if __name__=='__main__':
    main()
