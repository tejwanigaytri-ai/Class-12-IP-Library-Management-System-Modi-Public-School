import sqlite3
import datetime
import sys
# Dependencies required for advanced features
# If these imports fail, the user needs to run: pip install pandas matplotlib
try:
    import pandas as pd
    import matplotlib.pyplot as plt
except ImportError:
    # This block ensures the user sees a clear error if they haven't installed the libraries
    print("FATAL ERROR: Required libraries 'pandas' and 'matplotlib' are not installed.")
    print("Please open your terminal/command prompt and run the following command:")
    print(">>> pip install pandas matplotlib")
    sys.exit() 


# ================= CONFIGURATION =================
DB_NAME = "hotel_management.db"

# ================= UTILITY FUNCTIONS =================

def get_db_connection():
    """Establishes and returns a connection to the database."""
    # The detect_types argument allows us to read dates/timestamps correctly from the DB
    conn = sqlite3.connect(DB_NAME, detect_types=sqlite3.PARSE_DECLTYPES|sqlite3.PARSE_COLNAMES)
    return conn

def get_valid_int(prompt):
    """(Feature: Input Validation) Forces user to enter a valid integer."""
    while True:
        try:
            value = input(prompt)
            # Check if input is empty
            if not value.strip():
                print(">> [Error] Input cannot be empty. Please enter a value.")
                continue
            return int(value)
        except ValueError:
            print(">> [Error] Invalid input. Please enter a numeric value.")

def initialize_database():
    """Creates tables and inserts dummy data if the database is empty."""
    print("[-] System Initialization: Checking Database...")
    conn = get_db_connection()
    cursor = conn.cursor()

    # 1. Create Rooms Table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS rooms (
        room_no INTEGER PRIMARY KEY,
        room_type TEXT NOT NULL,
        price_per_night REAL NOT NULL,
        status TEXT DEFAULT 'Available'
    )
    ''')

    # 2. Create Bookings Table
    # Added column type affinity for better compatibility with Python's datetime
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS bookings (
        booking_id INTEGER PRIMARY KEY AUTOINCREMENT,
        guest_name TEXT NOT NULL,
        phone TEXT NOT NULL,
        room_no INTEGER,
        check_in_date DATE,
        check_out_date DATE,
        bill_amount REAL,
        FOREIGN KEY (room_no) REFERENCES rooms (room_no)
    )
    ''')

    # 3. Pre-populate Data (Only if rooms table is empty)
    cursor.execute('SELECT count(*) FROM rooms')
    if cursor.fetchone()[0] == 0:
        print("[-] First run detected. Populating dummy data...")
        
        # Add Rooms
        rooms_data = [
            (101, 'Standard', 1500, 'Available'), (102, 'Standard', 1500, 'Available'),
            (103, 'Standard', 1500, 'Available'), (201, 'Deluxe', 2500, 'Available'),
            (202, 'Deluxe', 2500, 'Available'), (301, 'Suite', 5000, 'Available')
        ]
        cursor.executemany('INSERT INTO rooms VALUES (?,?,?,?)', rooms_data)
        
        # Add Historical Bookings (for Charts) - Dates are stored as 'YYYY-MM-DD' strings
        history_data = [
            ('Amit Sharma', '9876543210', 101, '2023-10-01', '2023-10-03', 3000),
            ('Priya Verma', '9988776655', 201, '2023-10-05', '2023-10-07', 5000),
            ('Rahul Singh', '9123456789', 301, '2023-10-10', '2023-10-12', 10000),
            ('John Doe', '8888888888', 102, '2023-10-15', '2023-10-16', 1500),
            ('Jane Smith', '7777777777', 101, '2023-10-20', '2023-10-25', 7500),
            ('Vikram Rathore', '6665554443', 301, '2023-11-01', '2023-11-05', 20000)
        ]
        cursor.executemany('''
            INSERT INTO bookings (guest_name, phone, room_no, check_in_date, check_out_date, bill_amount)
            VALUES (?,?,?,?,?,?)
        ''', history_data)
        conn.commit()
        print("[-] Dummy data populated successfully.")

    conn.close()
    print("[-] Database Ready.\n")

# ================= CORE OPERATIONS =================

def check_in():
    conn = get_db_connection()
    
    # Read available rooms into a Pandas DataFrame for easy display
    try:
        df = pd.read_sql_query("SELECT * FROM rooms WHERE status = 'Available'", conn)
    except Exception as e:
        print(f"Error fetching room data: {e}")
        conn.close()
        return

    if df.empty:
        print(">> Sorry, No rooms available at the moment.")
        conn.close()
        return

    print("\n--- AVAILABLE ROOMS ---")
    # Using to_string() for clean console table output
    print(df[['room_no', 'room_type', 'price_per_night']].to_string(index=False))
    print("-" * 30)

    r_no = get_valid_int("Enter Room Number to Book: ")
    
    # Check if the entered room number is actually in the available list
    if r_no in df['room_no'].values:
        name = input("Enter Guest Name: ")
        phone = input("Enter Phone Number: ")
        # Store date object in DB (SQLite will convert this to 'YYYY-MM-DD' string)
        date_now = datetime.date.today() 
        
        cursor = conn.cursor()
        cursor.execute("UPDATE rooms SET status = 'Occupied' WHERE room_no = ?", (r_no,))
        cursor.execute("INSERT INTO bookings (guest_name, phone, room_no, check_in_date) VALUES (?, ?, ?, ?)", 
                       (name, phone, r_no, date_now))
        conn.commit()
        print(f"\n[+] Check-In Successful! {name} assigned to Room {r_no}.")
    else:
        print(">> Error: Room number is invalid or not available.")
    
    conn.close()

def check_out():
    conn = get_db_connection()
    cursor = conn.cursor()
    
    print("\n--- CHECK-OUT PROCESS ---")
    
    # Retrieve all necessary information for occupied rooms
    cursor.execute("""
        SELECT b.booking_id, b.room_no, b.guest_name, b.check_in_date, r.price_per_night 
        FROM bookings b
        JOIN rooms r ON b.room_no = r.room_no
        WHERE r.status = 'Occupied' AND b.check_out_date IS NULL
    """)
    active_bookings = cursor.fetchall() 
    
    if not active_bookings:
        print("No active guests found.")
        conn.close()
        return

    # Display active guests
    print(f"{'Room':<8} {'Guest Name':<20} {'Check-In Date'}")
    print("-" * 45)
    for row in active_bookings:
        # row indexes: 0=id, 1=room, 2=name, 3=date, 4=price
        print(f"{row[1]:<8} {row[2]:<20} {row[3]}")
    
    r_no = get_valid_int("\nEnter Room Number to Check Out: ")
    
    booking = None
    for row in active_bookings:
        if row[1] == r_no:
            booking = row
            break
            
    if booking:
        check_out_date = datetime.date.today()
        # Dates fetched from DB are already datetime.date objects due to connection setup
        check_in_date = booking[3] 
        
        days = (check_out_date - check_in_date).days
        if days <= 0: days = 1 # Ensures minimum 1 day charge
        
        rate = booking[4]
        total_bill = days * rate
        
        print(f"\n--- BILL SUMMARY ---")
        print(f"Guest: {booking[2]}")
        print(f"Duration: {days} Day(s) @ ₹{rate}/night")
        print(f"Total Amount: ₹{total_bill}")
        
        if input("Confirm Checkout? (y/n): ").lower() == 'y':
            # 1. Update Database
            cursor.execute("UPDATE rooms SET status = 'Available' WHERE room_no = ?", (r_no,))
            cursor.execute("UPDATE bookings SET check_out_date = ?, bill_amount = ? WHERE booking_id = ?", 
                           (check_out_date, total_bill, booking[0]))
            conn.commit()
            
            # 2. FEATURE: Generate Digital Invoice (File Handling)
            invoice_name = f"Invoice_{booking[2].replace(' ', '_')}_{booking[0]}.txt"
            with open(invoice_name, "w") as f:
                f.write("="*40 + "\n")
                f.write("       LUXE HOTEL - INVOICE\n")
                f.write("="*40 + "\n")
                f.write(f"Date:         {datetime.date.today().strftime('%Y-%m-%d')}\n")
                f.write(f"Guest Name:   {booking[2]}\n")
                f.write(f"Room Number:  {booking[1]}\n")
                f.write(f"Check-In:     {booking[3].strftime('%Y-%m-%d')}\n")
                f.write(f"Check-Out:    {check_out_date.strftime('%Y-%m-%d')}\n")
                f.write("-" * 40 + "\n")
                f.write(f"Total Amount: ₹{total_bill:.2f}\n")
                f.write("="*40 + "\n")
                f.write("Thank you for choosing Luxe Hotel!\n")
            
            print(f"[+] Checkout Complete.")
            print(f"[+] Digital Invoice saved as '{invoice_name}' in your project folder.")
    else:
        print(">> Room not found in active bookings.")
    
    conn.close()

def export_to_csv():
    """(Feature: Data Portability) Dumps all booking data to a CSV file."""
    conn = get_db_connection()
    try:
        # Load all booking data into a Pandas DataFrame
        df = pd.read_sql_query("SELECT * FROM bookings", conn)
        filename = "hotel_bookings_export.csv"
        # Export DataFrame to CSV file
        df.to_csv(filename, index=False)
        print(f"\n[+] Database successfully exported to '{filename}'")
        print("    You can now open this file in Microsoft Excel/Pandas.")
    except Exception as e:
        print(f">> Error exporting data: {e}")
    conn.close()

# ================= VISUALIZATION (BONUS) =================

def analytics_dashboard():
    conn = get_db_connection()
    
    while True:
        print("\n--- ANALYTICS DASHBOARD (Pandas & Matplotlib) ---")
        print("1. Revenue by Room Type (Bar Chart)")
        print("2. Occupancy Share (Pie Chart)")
        print("3. Back to Main Menu")
        
        ch = input("Choice: ")
        
        if ch == '1':
            # Query: Total revenue grouped by room type
            sql = """
                SELECT r.room_type, SUM(b.bill_amount) as total_revenue
                FROM bookings b
                JOIN rooms r ON b.room_no = r.room_no
                WHERE b.bill_amount IS NOT NULL
                GROUP BY r.room_type
            """
            df = pd.read_sql_query(sql, conn)
            
            if not df.empty and df['total_revenue'].sum() > 0:
                plt.figure(figsize=(8, 5))
                # Plotting directly using the Pandas-Matplotlib interface
                plt.bar(df['room_type'], df['total_revenue'], color=['#1f77b4', '#ff7f0e', '#2ca02c'])
                plt.title('Revenue by Room Type (Pandas Analysis)')
                plt.xlabel('Room Type')
                plt.ylabel('Revenue (INR)')
                plt.grid(axis='y', alpha=0.5)
                print(">> Graph generated. Please close the window to continue.")
                plt.show()
            else:
                print(">> Not enough completed checkout data to generate revenue chart.")

        elif ch == '2':
            # Query: Count of total bookings grouped by room type
            sql = """
                SELECT r.room_type, COUNT(*) as bookings_count
                FROM bookings b
                JOIN rooms r ON b.room_no = r.room_no
                GROUP BY r.room_type
            """
            df = pd.read_sql_query(sql, conn)
            
            if not df.empty and df['bookings_count'].sum() > 0:
                plt.figure(figsize=(7, 7))
                plt.pie(df['bookings_count'], labels=df['room_type'], autopct='%1.1f%%', 
                        startangle=140, colors=['#f1c40f', '#3498db', '#2ecc71'])
                plt.title('Booking Popularity Share')
                print(">> Graph generated. Please close the window to continue.")
                plt.show()
            else:
                print(">> Not enough booking data to generate chart.")
                
        elif ch == '3':
            break
        else:
            print("Invalid Choice.")
    
    conn.close()

# ================= MAIN MENU =================

def main():
    initialize_database()
    
    while True:
        print("\n" + "="*50)
        print("     LUXE HOTEL MANAGEMENT SYSTEM (V2.0)")
        print("     Python, SQL, Pandas, Matplotlib, File I/O")
        print("="*50)
        print("1. Check-In Guest (Input Validation Included)")
        print("2. Check-Out Guest (Generates Digital Invoice .txt)")
        print("3. View Analytics (Graphs)")
        print("4. Export Booking History to CSV")
        print("5. Exit")
        
        choice = input("\nEnter Option (1-5): ")
        
        if choice == '1':
            check_in()
        elif choice == '2':
            check_out()
        elif choice == '3':
            analytics_dashboard()
        elif choice == '4':
            export_to_csv()
        elif choice == '5':
            print("System Shutting Down... Goodbye!")
            sys.exit()
        else:
            print("Invalid input. Please try again.")

if __name__ == "__main__":
    main()