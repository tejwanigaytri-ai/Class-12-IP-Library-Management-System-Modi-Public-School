-------------------------------------------------------
LIBRARY MANAGEMENT SYSTEM - CBSE CLASS 12 (IP PROJECT)
-------------------------------------------------------

Student Name : Saransh Tejwani
Class & Section : XII Humanities
Roll Number : 13063
School : Modi Public School, Kota
Session : 2025–26
Subject Teacher : Mr. Vijay Nagar

-------------------------------------------------------
📌 PROJECT DESCRIPTION
-------------------------------------------------------
This Library Management System is a console-based software that helps 
schools maintain book inventory, student records, and book lending 
operations. It supports powerful search, analytics, and reporting tools.

-------------------------------------------------------
✨ FEATURES INCLUDED
-------------------------------------------------------
✔ Admin login with password hashing (SHA-256 security)
✔ Masked password input (hidden while typing)
✔ Fine calculation for late return
✔ Graphical analytics (Matplotlib)
✔ Dashboard for quick stats
✔ Track issue & return history
✔ Multi-admin support
✔ Book categories & filters
✔ Sort books by title, author, year, availability
✔ Search by multiple criteria (LIKE queries)
✔ Auto "Database Setup" on first run
✔ Shortcut-based menu navigation
✔ Secure database interaction (MySQL)

-------------------------------------------------------
🗄 DATABASE USED
-------------------------------------------------------
MySQL / MariaDB

Database Name:
    library

Tables Created:
    admin(username, password)
    students(student_id, name, class, contact)
    books(book_id, title, author, category, year, total_qty, available_qty)
    issued(issue_id, student_id, book_id, issue_date, due_date, return_date, fine)

-------------------------------------------------------
📦 PROJECT FOLDER STRUCTURE
-------------------------------------------------------
Library_Project/
│ main.py
│ db.py
│ db_init.sql
│ README.txt
│ project_report.docx   (optional)

-------------------------------------------------------
⚙ INSTALLATION
-------------------------------------------------------
Step 1: Install required Python libraries:
    pip install mysql-connector-python matplotlib

Step 2: Execute db_init.sql in MySQL:
    mysql -u root -p < db_init.sql

Step 3: Update MySQL password in db.py

Step 4: Run program:
    python main.py

-------------------------------------------------------
🔐 DEFAULT ADMIN LOGIN
-------------------------------------------------------
Username: admin
Password: admin123

(You can change password using "Reset Password" feature)

-------------------------------------------------------
🧑‍🏫 TEACHER REVIEW EXPECTATIONS
-------------------------------------------------------
✔ SQL Commands used
✔ User-defined functions
✔ Graphical Representation
✔ Authentication System
✔ Documentation & Output screenshots

-------------------------------------------------------
📌 SUBMISSION READY
-------------------------------------------------------
✔ Viva Questions included in report
✔ Error-free execution on school computer
✔ Extensible & future-proof code