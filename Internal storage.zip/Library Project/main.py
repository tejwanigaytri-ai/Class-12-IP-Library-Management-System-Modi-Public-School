"""
Library Management System (Console) - CBSE Class 12 IP (Full Premium)
Author: Saransh Tejwani
Roll No: 13063
School: Modi Public School, Kota
Session: 2025-26
Teacher: Vijay Nagar

Features (all included):
- Single-file console app (no separate db.py) — place this file in a folder and run
- MySQL backend (uses mysql-connector-python)
- Admin login with SHA-256 password hashing, masked input, multiple admins
- Password reset and admin management (add/remove)
- Dashboard (totals + overdue count)
- Graphical analytics (matplotlib): bar chart (issued per category) & pie (available vs issued)
- Add/View/Update/Delete books with categories/genres
- Add/View students
- Issue/Return books with automatic fine calculation and fine-payment tracking
- Issue history tracking (issue_history table)
- Reports (daily/monthly CSV export)
- Search (multi-criteria), Sort, Filter
- Menu shortcuts (numbers and letters)

Requirements:
- Python 3.8+
- mysql-connector-python (pip install mysql-connector-python)
- matplotlib (pip install matplotlib)
- A running MySQL server. Update DB credentials below.

Usage:
1) Create MySQL database using the included db_init.sql (or run ensure_db_schema() once from this script).
2) Update DB credentials in DB_CONFIG if necessary.
3) Run: python main.py

Note: This file attempts to be robust and user-friendly for CBSE project submission.
"""

import mysql.connector
from mysql.connector import Error
from datetime import date, timedelta, datetime
import getpass
import hashlib
import csv
import os
import sys
try:
    import matplotlib.pyplot as plt
except Exception:
    plt = None

# ---------- Configuration (change if your MySQL credentials differ) ----------
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': '',   # set your MySQL root password here
    'database': 'library_db'
}

FINE_PER_DAY = 1.0  # ₹ per day
DEFAULT_DUE_DAYS = 14
EXPORT_FOLDER = 'exports'

# ---------- Helper functions ----------

def hash_password(password: str) -> str:
    """Return SHA-256 hash of the password as hex string."""
    return hashlib.sha256(password.encode('utf-8')).hexdigest()


def get_connection():
    try:
        conn = mysql.connector.connect(
            host=DB_CONFIG['host'],
            user=DB_CONFIG['user'],
            password=DB_CONFIG['password'],
            database=DB_CONFIG['database']
        )
        return conn
    except Error as e:
        print("Error connecting to MySQL:", e)
        print("Make sure MySQL server is running and DB_CONFIG is correct.")
        sys.exit(1)


def ensure_db_schema():
    """Create required tables if they do not exist. Safe to run multiple times."""
    conn = None
    try:
        # Connect without database in case DB not created
        conn = mysql.connector.connect(host=DB_CONFIG['host'], user=DB_CONFIG['user'], password=DB_CONFIG['password'])
        cursor = conn.cursor()
        cursor.execute("CREATE DATABASE IF NOT EXISTS {}".format(DB_CONFIG['database']))
        conn.database = DB_CONFIG['database']

        # Create tables
        TABLES = {}
        TABLES['books'] = (
            "CREATE TABLE IF NOT EXISTS books ("
            "  book_id INT AUTO_INCREMENT PRIMARY KEY," 
            "  title VARCHAR(255) NOT NULL,") + (
            "  author VARCHAR(255), publisher VARCHAR(255), year_of_pub INT,") + (
            "  total_qty INT DEFAULT 1, available_qty INT DEFAULT 1, category VARCHAR(50)"
            ") ENGINE=InnoDB"
        )
        TABLES['students'] = (
            "CREATE TABLE IF NOT EXISTS students ("
            "  student_id INT AUTO_INCREMENT PRIMARY KEY," 
            "  adm_no VARCHAR(50) UNIQUE, name VARCHAR(255), class_sec VARCHAR(50)"
            ") ENGINE=InnoDB"
        )
        TABLES['admin'] = (
            "CREATE TABLE IF NOT EXISTS admin ("
            "  username VARCHAR(50) PRIMARY KEY, password VARCHAR(255) NOT NULL"
            ") ENGINE=InnoDB"
        )
        TABLES['issued'] = (
            "CREATE TABLE IF NOT EXISTS issued ("
            "  id INT AUTO_INCREMENT PRIMARY KEY, book_id INT, student_id INT,"
            "  issue_date DATE, due_date DATE, return_date DATE DEFAULT NULL, fine FLOAT DEFAULT 0,"
            "  FOREIGN KEY (book_id) REFERENCES books(book_id) ON DELETE CASCADE,"
            "  FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE"
            ") ENGINE=InnoDB"
        )
        TABLES['issue_history'] = (
            "CREATE TABLE IF NOT EXISTS issue_history ("
            "  id INT AUTO_INCREMENT PRIMARY KEY, book_id INT, student_id INT, issue_date DATE, return_date DATE, fine FLOAT,"
            "  FOREIGN KEY (book_id) REFERENCES books(book_id) ON DELETE SET NULL,"
            "  FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE SET NULL"
            ") ENGINE=InnoDB"
        )

        for name, ddl in TABLES.items():
            cursor.execute(ddl)

        # Insert default admin if not exists (username: admin, password: admin123)
        cursor.execute("SELECT COUNT(*) FROM admin")
        count = cursor.fetchone()[0]
        if count == 0:
            admin_pass = hash_password('admin123')
            cursor.execute("INSERT INTO admin (username, password) VALUES (%s, %s)", ('admin', admin_pass))
            conn.commit()

        # Insert sample books/students if empty
        cursor.execute("SELECT COUNT(*) FROM books")
        if cursor.fetchone()[0] == 0:
            sample_books = [
                ('Python Basics', 'Sumita Arora', 'TechPub', 2018, 10, 10, 'Science'),
                ('Informatics Practices', 'CBSE', 'CBSEPub', 2022, 15, 15, 'IP'),
                ('India After Gandhi', 'Ramachandra Guha', 'Picador', 2007, 2, 2, 'History')
            ]
            cursor.executemany(
                "INSERT INTO books (title, author, publisher, year_of_pub, total_qty, available_qty, category) VALUES (%s,%s,%s,%s,%s,%s,%s)",
                sample_books
            )
            conn.commit()

        cursor.execute("SELECT COUNT(*) FROM students")
        if cursor.fetchone()[0] == 0:
            cursor.execute("INSERT INTO students (adm_no, name, class_sec) VALUES (%s,%s,%s)", ('13063','Saransh Tejwani','XII Humanities'))
            conn.commit()

        print("Database schema ensured (tables exist).")
    except Error as e:
        print("Error creating schema:", e)
        sys.exit(1)
    finally:
        if conn:
            conn.close()


# ---------- Core functionality ----------

class Library:
    def __init__(self):
        self.conn = get_connection()
        self.cursor = self.conn.cursor(dictionary=True)
        os.makedirs(EXPORT_FOLDER, exist_ok=True)

    # ---------------- Admin management ----------------
    def login(self):
        print('\n----- Admin Login -----')
        username = input('Username: ').strip()
        password = getpass.getpass('Password: ')
        password_hash = hash_password(password)
        self.cursor.execute('SELECT * FROM admin WHERE username=%s AND password=%s', (username, password_hash))
        row = self.cursor.fetchone()
        if row:
            print('Login successful!\n')
            return username
        else:
            print('Invalid credentials. Try again.')
            return None

    def add_admin(self):
        print('\n--- Add Admin ---')
        username = input('New username: ').strip()
        password = getpass.getpass('Password: ')
        confirm = getpass.getpass('Confirm: ')
        if password != confirm:
            print('Passwords do not match.')
            return
        ph = hash_password(password)
        try:
            self.cursor.execute('INSERT INTO admin (username, password) VALUES (%s,%s)', (username, ph))
            self.conn.commit()
            print('Admin added.')
        except Error as e:
            print('Failed to add admin:', e)

    def reset_admin_password(self):
        print('\n--- Reset Admin Password ---')
        username = input('Username: ').strip()
        self.cursor.execute('SELECT * FROM admin WHERE username=%s', (username,))
        if not self.cursor.fetchone():
            print('Username not found.')
            return
        new = getpass.getpass('New password: ')
        confirm = getpass.getpass('Confirm: ')
        if new != confirm:
            print('Passwords do not match.')
            return
        ph = hash_password(new)
        self.cursor.execute('UPDATE admin SET password=%s WHERE username=%s', (ph, username))
        self.conn.commit()
        print('Password updated.')

    def remove_admin(self):
        print('\n--- Remove Admin ---')
        username = input('Username to remove: ').strip()
        if username == 'admin':
            print('Cannot remove default admin.')
            return
        self.cursor.execute('DELETE FROM admin WHERE username=%s', (username,))
        self.conn.commit()
        print('If existed, admin removed.')

    # ---------------- Book management ----------------
    def add_book(self):
        print('\n--- Add Book ---')
        title = input('Title: ').strip()
        author = input('Author: ').strip()
        publisher = input('Publisher: ').strip()
        try:
            year = int(input('Year of Publication: ').strip())
        except:
            year = None
        try:
            qty = int(input('Total copies: ').strip())
        except:
            qty = 1
        category = input('Category/Genre: ').strip() or 'General'
        self.cursor.execute('INSERT INTO books (title, author, publisher, year_of_pub, total_qty, available_qty, category) VALUES (%s,%s,%s,%s,%s,%s,%s)',
                            (title, author, publisher, year, qty, qty, category))
        self.conn.commit()
        print('Book added.')

    def view_books(self, rows=None):
        print('\n--- Books ---')
        if rows is None:
            self.cursor.execute('SELECT * FROM books')
            rows = self.cursor.fetchall()
        if not rows:
            print('No books found.')
            return
        print(f"{'ID':<4} {'Title':<30} {'Author':<20} {'Year':<6} {'Total':<6} {'Avail':<6} {'Category':<10}")
        for r in rows:
            print(f"{r['book_id']:<4} {r['title'][:29]:<30} {str(r.get('author',''))[:19]:<20} {str(r.get('year_of_pub','')):<6} {r['total_qty']:<6} {r['available_qty']:<6} {r.get('category','')[:9]:<10}")

    def update_book(self):
        print('\n--- Update Book ---')
        bid = input('Book ID: ').strip()
        self.cursor.execute('SELECT * FROM books WHERE book_id=%s', (bid,))
        row = self.cursor.fetchone()
        if not row:
            print('Book not found.')
            return
        title = input(f"Title [{row['title']}]: ").strip() or row['title']
        author = input(f"Author [{row.get('author','')}]: ").strip() or row.get('author')
        publisher = input(f"Publisher [{row.get('publisher','')}]: ").strip() or row.get('publisher')
        try:
            year = int(input(f"Year [{row.get('year_of_pub','')}]: ").strip() or row.get('year_of_pub'))
        except:
            year = row.get('year_of_pub')
        try:
            total = int(input(f"Total copies [{row['total_qty']}]: ").strip() or row['total_qty'])
        except:
            total = row['total_qty']
        # adjust available_qty proportionally if total changes
        avail = row['available_qty'] + (total - row['total_qty'])
        category = input(f"Category [{row.get('category','General')}]: ").strip() or row.get('category','General')
        self.cursor.execute('UPDATE books SET title=%s, author=%s, publisher=%s, year_of_pub=%s, total_qty=%s, available_qty=%s, category=%s WHERE book_id=%s',
                            (title, author, publisher, year, total, max(avail,0), category, bid))
        self.conn.commit()
        print('Book updated.')

    def delete_book(self):
        print('\n--- Delete Book ---')
        bid = input('Book ID to delete: ').strip()
        self.cursor.execute('DELETE FROM books WHERE book_id=%s', (bid,))
        self.conn.commit()
        print('If existed, book deleted.')

    # ---------------- Student management ----------------
    def add_student(self):
        print('\n--- Add Student ---')
        adm = input('Admission/Roll No: ').strip()
        name = input('Student Name: ').strip()
        cls = input('Class & Section: ').strip()
        try:
            self.cursor.execute('INSERT INTO students (adm_no, name, class_sec) VALUES (%s,%s,%s)', (adm, name, cls))
            self.conn.commit()
            print('Student added.')
        except Error as e:
            print('Failed to add student:', e)

    def view_students(self):
        print('\n--- Students ---')
        self.cursor.execute('SELECT * FROM students')
        rows = self.cursor.fetchall()
        if not rows:
            print('No students.')
            return
        print(f"{'ID':<4} {'AdmNo':<10} {'Name':<25} {'Class':<12}")
        for r in rows:
            print(f"{r['student_id']:<4} {r['adm_no']:<10} {r['name'][:24]:<25} {r['class_sec']:<12}")

    # ---------------- Issue & Return ----------------
    def issue_book(self):
        print('\n--- Issue Book ---')
        adm = input('Student Admission No: ').strip()
        self.cursor.execute('SELECT student_id, name FROM students WHERE adm_no=%s', (adm,))
        s = self.cursor.fetchone()
        if not s:
            print('Student not found. Add student first.')
            return
        bid = input('Book ID to issue: ').strip()
        self.cursor.execute('SELECT * FROM books WHERE book_id=%s', (bid,))
        b = self.cursor.fetchone()
        if not b:
            print('Book not found.')
            return
        if b['available_qty'] <= 0:
            print('No copies available.')
            return
        due_days = input(f'Due days (default {DEFAULT_DUE_DAYS}): ').strip()
        try:
            due_days = int(due_days) if due_days else DEFAULT_DUE_DAYS
        except:
            due_days = DEFAULT_DUE_DAYS
        issued_on = date.today()
        due_date = issued_on + timedelta(days=due_days)
        self.cursor.execute('INSERT INTO issued (book_id, student_id, issue_date, due_date) VALUES (%s,%s,%s,%s)',
                            (bid, s['student_id'], issued_on, due_date))
        self.cursor.execute('UPDATE books SET available_qty=available_qty-1 WHERE book_id=%s', (bid,))
        self.conn.commit()
        print('Book issued. Due date:', due_date)

    def view_issued(self):
        print('\n--- Issued Books ---')
        self.cursor.execute('SELECT i.id, b.book_id, b.title, s.adm_no, s.name, i.issue_date, i.due_date, i.return_date, i.fine FROM issued i JOIN books b ON i.book_id=b.book_id JOIN students s ON i.student_id=s.student_id ORDER BY i.issue_date DESC')
        rows = self.cursor.fetchall()
        if not rows:
            print('No issued books.')
            return
        print(f"{'TID':<4} {'BID':<4} {'Title':<25} {'Student':<10} {'IssuedOn':<12} {'DueDate':<12} {'Returned':<10} {'Fine':<5}")
        for r in rows:
            returned = r['return_date'].strftime('%Y-%m-%d') if r['return_date'] else 'No'
            print(f"{r['id']:<4} {r['book_id']:<4} {r['title'][:24]:<25} {r['adm_no']:<10} {r['issue_date']:%Y-%m-%d} {r['due_date']:%Y-%m-%d} {returned:<10} {r['fine']:<5}")

    def return_book(self):
        print('\n--- Return Book ---')
        tid = input('Transaction ID: ').strip()
        self.cursor.execute('SELECT * FROM issued WHERE id=%s', (tid,))
        trans = self.cursor.fetchone()
        if not trans:
            print('Transaction not found.')
            return
        if trans['return_date']:
            print('Book already returned on', trans['return_date'])
            return
        returned_on = date.today()
        due = trans['due_date']
        fine = 0.0
        if returned_on > due:
            days = (returned_on - due).days
            fine = days * FINE_PER_DAY
        # update issued
        self.cursor.execute('UPDATE issued SET return_date=%s, fine=%s WHERE id=%s', (returned_on, fine, tid))
        # insert into issue_history
        self.cursor.execute('INSERT INTO issue_history (book_id, student_id, issue_date, return_date, fine) VALUES (%s,%s,%s,%s,%s)',
                            (trans['book_id'], trans['student_id'], trans['issue_date'], returned_on, fine))
        # increment book availability
        self.cursor.execute('UPDATE books SET available_qty=available_qty+1 WHERE book_id=%s', (trans['book_id'],))
        self.conn.commit()
        print(f'Returned. Fine: ₹{fine:.2f}')

    def pay_fine(self):
        print('\n--- Fine Payment ---')
        tid = input('Transaction ID: ').strip()
        self.cursor.execute('SELECT * FROM issued WHERE id=%s', (tid,))
        trans = self.cursor.fetchone()
        if not trans:
            print('Transaction not found.')
            return
        if trans['fine'] <= 0:
            print('No fine due for this transaction.')
            return
        print(f"Fine due: ₹{trans['fine']:.2f}")
        confirm = input('Mark as paid? (Y/N): ').strip().upper()
        if confirm == 'Y':
            # set fine to 0 in issued and history (optional: record payment in separate table)
            self.cursor.execute('UPDATE issued SET fine=0 WHERE id=%s', (tid,))
            self.conn.commit()
            print('Fine marked as paid.')
        else:
            print('Payment cancelled.')

    # ---------------- Search / Sort / Filter ----------------
    def search_books(self):
        print('\n--- Search Books (leave blank to skip a field) ---')
        title = input('Title: ').strip()
        author = input('Author: ').strip()
        year = input('Year: ').strip()
        publisher = input('Publisher: ').strip()
        category = input('Category: ').strip()
        query = 'SELECT * FROM books WHERE 1=1'
        params = []
        if title:
            query += ' AND title LIKE %s'
            params.append(f"%{title}%")
        if author:
            query += ' AND author LIKE %s'
            params.append(f"%{author}%")
        if year:
            query += ' AND year_of_pub=%s'
            params.append(year)
        if publisher:
            query += ' AND publisher LIKE %s'
            params.append(f"%{publisher}%")
        if category:
            query += ' AND category LIKE %s'
            params.append(f"%{category}%")
        self.cursor.execute(query, tuple(params))
        rows = self.cursor.fetchall()
        self.view_books(rows)

    def sort_books(self):
        print('\nSort by: 1.Title 2.Author 3.Year 4.Availability 5.Category')
        ch = input('Choice: ').strip()
        mapping = {'1':'title','2':'author','3':'year_of_pub','4':'available_qty','5':'category'}
        orderby = mapping.get(ch,'title')
        self.cursor.execute(f'SELECT * FROM books ORDER BY {orderby}')
        rows = self.cursor.fetchall()
        self.view_books(rows)

    def filter_by_category(self):
        cat = input('Enter category: ').strip()
        self.cursor.execute('SELECT * FROM books WHERE category LIKE %s', (f"%{cat}%",))
        rows = self.cursor.fetchall()
        self.view_books(rows)

    # ---------------- Reports & Exports ----------------
    def generate_report(self):
        print('\n--- Generate Report ---')
        print('1. Daily Report (today)')
        print('2. Monthly Report (this month)')
        ch = input('Choice: ').strip()
        if ch == '1':
            date_cond = "(issue_date=CURDATE() OR return_date=CURDATE())"
            fname = f"{EXPORT_FOLDER}/report_daily_{date.today()}.csv"
        else:
            date_cond = "(MONTH(issue_date)=MONTH(CURDATE()) OR MONTH(return_date)=MONTH(CURDATE()))"
            fname = f"{EXPORT_FOLDER}/report_monthly_{date.today().strftime('%Y_%m')}.csv"
        q = f"SELECT * FROM issue_history WHERE {date_cond}"
        self.cursor.execute(q)
        rows = self.cursor.fetchall()
        if not rows:
            print('No records for the selected period.')
            return
        keys = rows[0].keys()
        with open(fname, 'w', newline='', encoding='utf-8') as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=keys)
            writer.writeheader()
            for r in rows:
                writer.writerow(r)
        print('Report exported to', fname)

    # ---------------- Issue History ----------------
    def show_issue_history(self):
        print('\n--- Issue History (All) ---')
        self.cursor.execute('SELECT ih.id, b.title, s.adm_no, s.name, ih.issue_date, ih.return_date, ih.fine FROM issue_history ih JOIN books b ON ih.book_id=b.book_id JOIN students s ON ih.student_id=s.student_id ORDER BY ih.issue_date DESC')
        rows = self.cursor.fetchall()
        if not rows:
            print('No history records.')
            return
        print(f"{'ID':<4} {'Title':<25} {'AdmNo':<8} {'Name':<20} {'Issue':<12} {'Return':<12} {'Fine':<5}")
        for r in rows:
            ret = r['return_date'].strftime('%Y-%m-%d') if r['return_date'] else ''
            print(f"{r['id']:<4} {r['title'][:24]:<25} {r['adm_no']:<8} {r['name'][:19]:<20} {r['issue_date']:%Y-%m-%d} {ret:<12} {r['fine']:<5}")

    # ---------------- Analytics wrapper (safe if matplotlib missing) ----------------
    def analytics(self):
        if plt is None:
            print('matplotlib not installed. Analytics unavailable. Install with: pip install matplotlib')
            return
        # bar chart
        self.cursor.execute('SELECT b.category, COUNT(i.id) as issued_count FROM books b LEFT JOIN issued i ON b.book_id=i.book_id GROUP BY b.category')
        data = self.cursor.fetchall()
        cats = [d['category'] or 'Unk' for d in data]
        counts = [d['issued_count'] for d in data]
        if any(counts):
            plt.figure()
            plt.bar(cats, counts)
            plt.title('Books Issued per Category')
            plt.xlabel('Category')
            plt.ylabel('Issued Count')
            plt.tight_layout()
            plt.show()
        # pie chart available vs issued
        self.cursor.execute('SELECT IFNULL(SUM(available_qty),0) AS avail, IFNULL(SUM(total_qty),0) AS total FROM books')
        row = self.cursor.fetchone()
        avail = row['avail'] or 0
        total = row['total'] or 0
        issued = max(total - avail, 0)
        if total>0:
            plt.figure()
            plt.pie([avail, issued], labels=['Available','Issued'], autopct='%1.1f%%')
            plt.title('Available vs Issued Books')
            plt.tight_layout()
            plt.show()

    # ---------------- Close ----------------
    def close(self):
        if self.conn:
            self.cursor.close()
            self.conn.close()


# ---------- Menu & Interaction ----------

def main_menu(lib: Library, admin_user: str):
    while True:
        print('\n===== Library Management System =====')
        print('A. Dashboard | B. Analytics | C. Add Book | D. View Books | E. Update Book | F. Delete Book')
        print('G. Add Student | H. View Students | I. Issue Book | J. View Issued | K. Return Book')
        print('L. Pay Fine | M. Search Books | N. Sort Books | O. Filter by Category | P. Issue History')
        print('Q. Generate Report | R. Admin Menu | S. Logout | 0. Exit')
        choice = input('\nEnter choice (letter/number): ').strip().upper()
        if choice in ('A','1'):
            lib.show_dashboard()
        elif choice in ('B','2'):
            lib.analytics()
        elif choice in ('C','3'):
            lib.add_book()
        elif choice in ('D','4'):
            lib.view_books()
        elif choice in ('E','5'):
            lib.update_book()
        elif choice in ('F','6'):
            lib.delete_book()
        elif choice in ('G','7'):
            lib.add_student()
        elif choice in ('H','8'):
            lib.view_students()
        elif choice in ('I','9'):
            lib.issue_book()
        elif choice in ('J','10'):
            lib.view_issued()
        elif choice in ('K','11'):
            lib.return_book()
        elif choice in ('L','12'):
            lib.pay_fine()
        elif choice in ('M','13'):
            lib.search_books()
        elif choice in ('N','14'):
            lib.sort_books()
        elif choice in ('O','15'):
            lib.filter_by_category()
        elif choice in ('P','16'):
            lib.show_issue_history()
        elif choice in ('Q','17'):
            lib.generate_report()
        elif choice in ('R','18'):
            admin_submenu(lib)
        elif choice in ('S',):
            print('Logging out...')
            break
        elif choice in ('0',):
            print('Exiting application...')
            lib.close()
            sys.exit(0)
        else:
            print('Invalid choice. Try again.')


def admin_submenu(lib: Library):
    while True:
        print('\n--- Admin Menu ---')
        print('1. Add Admin | 2. Reset Admin Password | 3. Remove Admin | 0. Back')
        ch = input('Choice: ').strip()
        if ch == '1':
            lib.add_admin()
        elif ch == '2':
            lib.reset_admin_password()
        elif ch == '3':
            lib.remove_admin()
        elif ch == '0':
            break
        else:
            print('Invalid choice')


# ---------- Run Application ----------
if __name__ == '__main__':
    print('Starting Library Management System...')
    ensure_db_schema()  # create DB and tables if needed
    library = Library()

    while True:
        print('\n1. Login | 2. Reset Admin Password | 3. Exit')
        choice = input('Enter choice: ').strip()
        if choice == '1':
            user = library.login()
            if user:
                main_menu(library, user)
        elif choice == '2':
            library.reset_admin_password()
        elif choice == '3':
            print('Goodbye!')
            library.close()
            break
        else:
            print('Invalid choice.')
