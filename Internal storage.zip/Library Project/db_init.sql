-- Database Initialization Script for Library Management System
-- Creates database, tables, and sample data

DROP DATABASE IF EXISTS library;
CREATE DATABASE library;
USE library;

-- Admin table with hashed passwords
CREATE TABLE admin (
    username VARCHAR(50) PRIMARY KEY,
    password VARCHAR(64) NOT NULL
);

INSERT INTO admin VALUES ('admin', SHA2('admin123',256));

-- Students table
CREATE TABLE students (
    student_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100),
    class VARCHAR(10),
    contact VARCHAR(15)
);

-- Books table
CREATE TABLE books (
    book_id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(200),
    author VARCHAR(150),
    category VARCHAR(50),
    year INT,
    total_qty INT,
    available_qty INT
);

-- Issued Books table
CREATE TABLE issued (
    issue_id INT PRIMARY KEY AUTO_INCREMENT,
    student_id INT,
    book_id INT,
    issue_date DATE,
    due_date DATE,
    return_date DATE,
    fine INT DEFAULT 0,
    FOREIGN KEY (student_id) REFERENCES students(student_id),
    FOREIGN KEY (book_id) REFERENCES books(book_id)
);

-- Sample Data Insert
INSERT INTO students (name, class, contact) VALUES
('Aarav Sharma', 'XII-A', '9876543210'),
('Shruti Verma', 'XI-B', '9123456780');

INSERT INTO books (title, author, category, year, total_qty, available_qty) VALUES
('Python Programming', 'Mark Lutz', 'Computer Science', 2015, 5, 5),
('India History', 'Ramachandra Guha', 'History', 2010, 4, 4),
('Chemistry Part I', 'NCERT', 'Science', 2021, 6, 6),
('Macbeth', 'William Shakespeare', 'Literature', 2008, 3, 3);

SELECT * FROM admin;
