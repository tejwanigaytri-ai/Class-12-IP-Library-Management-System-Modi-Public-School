-- Database Initialization Script for Library Management System
-- Creates tables: admins, students, books, issue_history, fines

DROP TABLE IF EXISTS fines;
DROP TABLE IF EXISTS issue_history;
DROP TABLE IF EXISTS books;
DROP TABLE IF EXISTS students;
DROP TABLE IF EXISTS admins;

-- Admin Table
CREATE TABLE IF NOT EXISTS admins (
    admin_id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL
);

-- Default Admin Insert
INSERT INTO admins (username, password_hash)
VALUES ('admin', 'default_hash_replace_on_first_run');

-- Student Table
CREATE TABLE IF NOT EXISTS students (
    student_id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    class TEXT,
    roll_number TEXT
);

-- Books Table
CREATE TABLE IF NOT EXISTS books (
    book_id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    author TEXT,
    category TEXT,
    year INTEGER,
    status TEXT DEFAULT 'available'
);

-- Issue History Table
CREATE TABLE IF NOT EXISTS issue_history (
    transaction_id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER,
    book_id INTEGER,
    issue_date TEXT,
    due_date TEXT,
    return_date TEXT,
    fine_collected REAL DEFAULT 0,
    FOREIGN KEY(student_id) REFERENCES students(student_id),
    FOREIGN KEY(book_id) REFERENCES books(book_id)
);

-- Fines Table
CREATE TABLE IF NOT EXISTS fines (
    fine_id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER,
    transaction_id INTEGER,
    amount REAL,
    paid INTEGER DEFAULT 0,
    FOREIGN KEY(student_id) REFERENCES students(student_id),
    FOREIGN KEY(transaction_id) REFERENCES issue_history(transaction_id)
);

-- Sample Data (Optional)
INSERT INTO students (name, class, roll_number) VALUES
('Aarav Verma', 'XII-A', '101'),
('Sanya Kapoor', 'XII-B', '102');

INSERT INTO books (title, author, category, year) VALUES
('Python Made Easy', 'S. Sharma', 'IP', 2022),
('Indian History', 'R. Thapar', 'History', 2020),
('Science Explorer', 'K. Rao', 'Science', 2021);
